package com.avigmatechnologies.demo_application;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.BreakIterator;
import java.util.Calendar;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

import static com.avigmatechnologies.demo_application.DBManager.str;

public class SecondActivity extends AppCompatActivity {
    @BindView(R.id.save_record)
    Button saveRecord;

    @BindView(R.id.display_last_save_no)
    Button displayLastSaveNo;

    @BindView(R.id.open_time_picker_dialog)
    Button openTimePickerDialog;

    @BindView(R.id.txtTime)
    EditText txtTime;

    @BindView(R.id.back_to_main)
    Button backToMain;

    private int mHour, mMinute;
    private DBManager dbManager;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        ButterKnife.bind(this);
        dbManager = new DBManager(this);
        dbManager.open();
    }

    @OnClick({R.id.save_record, R.id.display_last_save_no, R.id.open_time_picker_dialog, R.id.back_to_main})
    public void onViewClick(View view) {
        switch (view.getId()) {
            case R.id.save_record:
                saveRecordInDb();
                break;
            case R.id.display_last_save_no:
                getLastRecordFromDb();
                break;
            case R.id.open_time_picker_dialog:
                setTime();
                break;
            case R.id.back_to_main:
                startActivity(new Intent(SecondActivity.this, MainActivity.class));
                break;
        }
    }

    private void getLastRecordFromDb() {
        dbManager.getNumber();
        Toast.makeText(SecondActivity.this,"Data :"+str ,Toast.LENGTH_LONG).show();

    }

    private void saveRecordInDb() {
        final String text = txtTime.getText().toString();
        dbManager.insert(text);
        Toast.makeText(SecondActivity.this,"Data Saved Successfully",Toast.LENGTH_LONG).show();
    }

    private void setTime() {
        final Calendar c = Calendar.getInstance();
        mHour = c.get(Calendar.HOUR_OF_DAY);
        mMinute = c.get(Calendar.MINUTE);
        TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                new TimePickerDialog.OnTimeSetListener() {

                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay,
                                          int minute) {
                        setNotification();
                        txtTime.setText(hourOfDay + ":" + minute);
                    }
                }, mHour, mMinute, false);
        timePickerDialog.show();
    }

    private void setNotification() {
        Intent notifyIntent = new Intent(this,MyReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast
                (this,0, notifyIntent, PendingIntent.FLAG_UPDATE_CURRENT);
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,  System.currentTimeMillis(),
                1000 * 60 * 60 * 24, pendingIntent);

    }
}
