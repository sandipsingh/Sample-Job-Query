package com.avigmatechnologies.demo_application;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.provider.SyncStateContract;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity {
    @BindView(R.id.push_notification)
    Button pushNotiBtn;

    @BindView(R.id.next_Activity)
    Button NextActivityBtn;

    @BindView(R.id.show_time)
    TextView showTime;

    NotificationHelper noti;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);


        String sessionId= getIntent().getStringExtra("notify");

        if(sessionId != null){
            showPopUp();
        }
        noti = new NotificationHelper(this);

        long date = System.currentTimeMillis();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        String dateString = sdf.format(date);
        showTime.setText(dateString);
    }

    private void showPopUp() {
        AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity.this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.child_data, null);
        alert.setView(dialogView);

        alert.setNegativeButton("No", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getBaseContext(), "No clicked", Toast.LENGTH_SHORT).show();
                dialog.cancel();
            }
        });

        alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getBaseContext(), "Yes Clicked", Toast.LENGTH_SHORT).show();
                dialog.cancel();
            }
        });
        AlertDialog dialog = alert.create();
        dialog.show();
}

    @OnClick({R.id.push_notification, R.id.next_Activity})
    public void onViewClick(View view) {
        switch (view.getId()) {
            case R.id.push_notification:
                String title ="Notifications Title";
                String message="Your First Activity notification.";
                noti.createNotification(title,message);
                break;

            case R.id.next_Activity:
                startActivity(new Intent(MainActivity.this, SecondActivity.class)
                        .setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK));
                break;
        }
    }

}
